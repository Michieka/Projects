Ext.onReady(function()
{
	intelli.admin.init();
});
