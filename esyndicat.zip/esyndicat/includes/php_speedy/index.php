<?php
require('install.php');
?>